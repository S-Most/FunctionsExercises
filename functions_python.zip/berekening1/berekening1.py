def berekening():

    # Schrijf hier jouw code om de berekening te printen

    print(uitkomst)

# FunctieAanroep
berekening(8, "-", 3)
berekening(3, "+", 6)
berekening(0, "-", 2)