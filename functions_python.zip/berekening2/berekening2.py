def berekening():

    # Schrijf hier jouw code om de berekening te laten printen aan het einde van je script


# FunctieAanroep


# Printen van de uitkomst
print(uitkomst)